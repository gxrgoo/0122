const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: '127.0.0.1',
    user: 'root',
    password: '',
    database: 'people_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

async function selectall() {
    const query = 'SELECT * FROM ujemberek;';
    const [rows] = await pool.execute(query);
    return rows;
}

async function selectById(id) {
  const [rows] = await pool.execute(
    "SELECT * FROM ujemberek WHERE ember_id = ? LIMIT 1;",
    [id]
  );
  return rows.length ? rows[0] : null;
}

async function updatePersonPatch(id, fields) {

  // Csak ezek a mezők módosíthatók a Mentés gombbal
  const allowed = new Set([
    "vezeteknev",
    "keresztnev",
    "varos",
    "email",
    "aktiv"
  ]);

  // Ha nincs adat vagy nem objektum → nincs mit menteni
  if (!fields || typeof fields !== "object") {
    return 0;
  }

  // A beérkező mezők közül csak az engedélyezettek maradnak
  const incomingKeys = Object.keys(fields)
    .filter((k) => allowed.has(k));

  // Ha semmi nem maradt → nincs frissítés
  if (incomingKeys.length === 0) {
    return 0;
  }

  // Lekérjük az aktuális adatot az adatbázisból
  // (összehasonlításhoz kell)
  const current = await selectById(id);

  // Ha nincs ilyen ID → nincs mit módosítani
  if (!current) {
    return 0;
  }

  // true / "true" / 1 → 1
  // minden más → 0
  const normalizeAktiv = (v) =>
    v === true ||
    v === 1 ||
    v === "1" ||
    String(v).toLowerCase() === "true"
      ? 1
      : 0;

  // Ebbe az objektumba gyűjtjük a megváltozott mezőket
  const changes = {};

  // Végigmegyünk az engedélyezett, beérkező mezőkön
  for (const k of incomingKeys) {
    let newVal = fields[k];

    // Külön kezelés az "aktiv" mezőre
    if (k === "aktiv") {

      // Új és régi érték egységesítése (0 / 1)
      const normalizedNew = normalizeAktiv(newVal);
      const normalizedOld = normalizeAktiv(current.aktiv);

      // Csak akkor mentjük el, ha valóban változott
      if (normalizedNew !== normalizedOld) {
        changes[k] = normalizedNew;
      }

    } else {

      // Minden más mezőt stringgé alakítunk
      // (null / undefined kezelés miatt)
      const newStr = String(newVal ?? "");
      const oldStr = String(current[k] ?? "");

      // Csak akkor mentjük el, ha különbözik
      if (newStr !== oldStr) {
        changes[k] = newStr;
      }
    }
  }

  // Ha nincs egyetlen tényleges változás sem
  // nincs UPDATE
  const keys = Object.keys(changes);
  if (keys.length === 0) {
    return 0;
  }

  // SQL SET rész dinamikus összeállítása
  // pl.: "vezeteknev = ?, email = ?"
  const setSql = keys
    .map((k) => `${k} = ?`)
    .join(", ");

  // A SET-hez tartozó értékek sorrendben
  const values = keys.map((k) => changes[k]);

  // SQL UPDATE parancs
  const sql = `
    UPDATE ujemberek
    SET ${setSql}
    WHERE ember_id = ?;
  `;

  // SQL végrehajtása paraméterezve (SQL injection ellen védett)
  const [result] = await pool.execute(sql, [...values, id]);

  // affectedRows:
  // 1 → sikeres módosítás
  // 0 → nem történt változás
  return result.affectedRows;
}

async function deleteById(id) {

  // SQL törlés parancs ID alapján
  const sql = "DELETE FROM ujemberek WHERE ember_id = ?;";

  // SQL végrehajtása paraméterrel
  const [result] = await pool.execute(sql, [id]);

  return result.affectedRows;
}

const bcrypt = require("bcrypt");





//!Export
module.exports = {
    selectall,
    updatePersonPatch,
    selectById,
    deleteById,
    felhletrehozas,
    kivalasztfelh
};
