const mysql = require("mysql2/promise");

const pool = mysql.createPool({
  host: "127.0.0.1",
  user: "root",
  password: "",
  database: "people_db",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// --- segédfüggvények ---
function toStr(v) {
  return String(v ?? "").trim();
}

function toUInt(v) {
  const n = Number(v);
  return Number.isFinite(n) ? Math.trunc(n) : NaN;
}

function toAktiv(v) {
  return v === true ||
    v === 1 ||
    v === "1" ||
    String(v).toLowerCase() === "true"
    ? 1
    : 0;
}

function toDateStr(v) {
  // a frontend <input type="date"> YYYY-MM-DD-t ad
  return toStr(v);
}

// --- SELECT ALL ---
async function selectall() {
  const sql = "SELECT * FROM ujemberek;";
  const [rows] = await pool.execute(sql);
  return rows;
}

// --- SELECT BY ID ---
async function selectById(id) {
  const sql = "SELECT * FROM ujemberek WHERE ember_id = ? LIMIT 1;";
  const [rows] = await pool.execute(sql, [id]);
  return rows.length ? rows[0] : null;
}

// --- SELECT BY EMAIL ---
async function selectByEmail(email) {
  const em = toStr(email);
  if (!em) return null;

  const sql = "SELECT * FROM ujemberek WHERE email = ? LIMIT 1;";
  const [rows] = await pool.execute(sql, [em]);
  return rows.length ? rows[0] : null;
}

// --- SELECT BY USERNAME (felhasznalonev UNIQUE miatt) ---
async function selectByFelhasznalonev(felhasznalonev) {
  const u = toStr(felhasznalonev);
  if (!u) return null;

  const sql = "SELECT * FROM ujemberek WHERE felhasznalonev = ? LIMIT 1;";
  const [rows] = await pool.execute(sql, [u]);
  return rows.length ? rows[0] : null;
}

// --- INSERT ---
// A táblád alapján MINDEN mező NOT NULL, ezért itt mindet be kell szúrni (ember_id-t nem, ha AUTO_INCREMENT).
async function insertPerson(person) {
  const p = person || {};

  const vezeteknev = toStr(p.vezeteknev);
  const keresztnev = toStr(p.keresztnev);
  const nem = toStr(p.nem); // 'férfi' | 'nő'
  const szuletesi_datum = toDateStr(p.szuletesi_datum);
  const eletkor = toUInt(p.eletkor); // API számolja
  const email = toStr(p.email);
  const telefon = toStr(p.telefon);
  const varos = toStr(p.varos);
  const iranyitoszam = toUInt(p.iranyitoszam);
  const foglalkozas = toStr(p.foglalkozas);
  const fizetes = toUInt(p.fizetes);
  const belepes_datuma = toDateStr(p.belepes_datuma);
  const aktiv = toAktiv(p.aktiv);
  const megjegyzes = toStr(p.megjegyzes);
  const felhasznalonev = toStr(p.felhasznalonev);
  const jelszo = toStr(p.jelszo); // CHAR(8)

  const sql = `
    INSERT INTO ujemberek (
      vezeteknev, keresztnev, nem, szuletesi_datum, eletkor,
      email, telefon, varos, iranyitoszam, foglalkozas, fizetes,
      belepes_datuma, aktiv, megjegyzes, felhasznalonev, jelszo
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
  `;

  const [result] = await pool.execute(sql, [
    vezeteknev,
    keresztnev,
    nem,
    szuletesi_datum,
    eletkor,
    email,
    telefon,
    varos,
    iranyitoszam,
    foglalkozas,
    fizetes,
    belepes_datuma,
    aktiv,
    megjegyzes,
    felhasznalonev,
    jelszo,
  ]);

  return {
    insertId: result.insertId,
    affectedRows: result.affectedRows,
  };
}

async function insertUjFelhasznalo(data) {
  const d = data || {};

  const ujnev = toStr(d.ujnev);
  const ujfelhasznalonev = toStr(d.ujfelhasznalonev);
  const ujemail = toStr(d.ujemail);
  const ujjelszo = toStr(d.ujjelszo);

  const sql = `
    INSERT INTO ujtabela (
      ujnev,
      ujfelhasznalonev,
      ujemail,
      ujjelszo
    )
    VALUES (?, ?, ?, ?);
  `;

  const [result] = await pool.execute(sql, [
    ujnev,
    ujfelhasznalonev,
    ujemail,
    ujjelszo,
  ]);

  return {
    insertId: result.insertId,
    affectedRows: result.affectedRows,
  };
}






// --- PATCH UPDATE (csak változások mentése) ---
async function updatePersonPatch(id, fields) {
  // Engedélyezett mezők (ember_id sosem módosítható)
  const allowed = new Set([
    "vezeteknev",
    "keresztnev",
    "nem",
    "szuletesi_datum",
    "eletkor",
    "email",
    "telefon",
    "varos",
    "iranyitoszam",
    "foglalkozas",
    "fizetes",
    "belepes_datuma",
    "aktiv",
    "megjegyzes",
    "felhasznalonev",
    "jelszo",
  ]);

  if (!fields || typeof fields !== "object") return 0;

  const incomingKeys = Object.keys(fields).filter((k) => allowed.has(k));
  if (incomingKeys.length === 0) return 0;

  const current = await selectById(id);
  if (!current) return 0;

  const changes = {};

  for (const k of incomingKeys) {
    const newVal = fields[k];

    if (k === "aktiv") {
      const nNew = toAktiv(newVal);
      const nOld = toAktiv(current.aktiv);
      if (nNew !== nOld) changes[k] = nNew;

    } else if (k === "szuletesi_datum" || k === "belepes_datuma") {
      const nNew = toDateStr(newVal);
      const nOld = String(current[k] ?? "");
      if (nNew !== nOld) changes[k] = nNew;

    } else if (k === "eletkor" || k === "iranyitoszam" || k === "fizetes") {
      const nNew = toUInt(newVal);
      const nOld = toUInt(current[k]);
      if (Number.isFinite(nNew) && nNew !== nOld) changes[k] = nNew;

    } else {
      const nNew = String(newVal ?? "");
      const nOld = String(current[k] ?? "");
      if (nNew !== nOld) changes[k] = nNew;
    }
  }

  const keys = Object.keys(changes);
  if (keys.length === 0) return 0;

  const setSql = keys.map((k) => `${k} = ?`).join(", ");
  const values = keys.map((k) => changes[k]);

  const sql = `
    UPDATE ujemberek
    SET ${setSql}
    WHERE ember_id = ?;
  `;

  const [result] = await pool.execute(sql, [...values, id]);
  return result.affectedRows;
}

// --- DELETE ---
async function deleteById(id) {
  const sql = "DELETE FROM ujemberek WHERE ember_id = ?;";
  const [result] = await pool.execute(sql, [id]);
  return result.affectedRows;
}

// --- EXPORT ---
module.exports = {
  selectall,
  selectById,
  selectByEmail,
  selectByFelhasznalonev,
  insertPerson,
  updatePersonPatch,
  deleteById,
  insertUjFelhasznalo
};
