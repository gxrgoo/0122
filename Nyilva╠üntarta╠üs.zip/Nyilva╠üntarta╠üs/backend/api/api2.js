const express = require('express');
const router = express.Router();
const database = require('../sql/database.js');
const fs = require('fs/promises');

//!Multer
const multer = require('multer'); //?npm install multer
const path = require('path');

const storage = multer.diskStorage({
    destination: (request, file, callback) => {
        callback(null, path.join(__dirname, '../uploads'));
    },
    filename: (request, file, callback) => {
        callback(null, Date.now() + '-' + file.originalname); //?egyedi név: dátum - file eredeti neve
    }
});

const upload = multer({ storage });

//!Endpoints:
//?GET /api/test
router.get('/test', (request, response) => {
    response.status(200).json({
        message: 'Ez a végpont működik.'
    });
});

//?GET /api/testsql
router.get('/testsql', async (request, response) => {
    try {
        const selectall = await database.selectall();
        response.status(200).json({
            message: 'Ez a végpont működik.',
            results: selectall
        });
    } catch (error) {
        response.status(500).json({
            message: 'Ez a végpont nem működik.'
        });
    }
});

router.patch("/ujemberek/:id", async (req, res) => {
  try {
    // 1) ID validáció
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ message: "Hibás ID. Pozitív egész szám szükséges." });
    }

    // 2) Content-Type ellenőrzés (nem kötelező, de hasznos)
    const ct = req.headers["content-type"] || "";
    if (!ct.includes("application/json")) {
      return res.status(415).json({ message: "Content-Type legyen application/json." });
    }

    // 3) Body ellenőrzés
    const body = req.body;
    if (!body || Object.keys(body).length === 0) {
      return res.status(400).json({ message: "Üres kérés. Nincs módosítandó mező." });
    }

    // 4) Engedélyezett mezők (biztonság)
    const allowed = new Set(["vezeteknev", "keresztnev", "varos", "email", "aktiv"]);
    const updates = {};

    for (const [key, value] of Object.entries(body)) {
      if (!allowed.has(key)) {
        return res.status(422).json({ message: `Nem módosítható mező: ${key}` });
      }
      updates[key] = value;
    }

    // 5) Típus/érték ellenőrzések (pár alap)
    if (updates.email !== undefined) {
      const email = String(updates.email);
      // nagyon egyszerű email check
      if (!email.includes("@") || email.length < 6) {
        return res.status(422).json({ message: "Hibás email formátum." });
      }
    }

    if (updates.aktiv !== undefined) {
      // boolean -> 0/1
      updates.aktiv =
        updates.aktiv === true ||
        updates.aktiv === 1 ||
        updates.aktiv === "1" ||
        String(updates.aktiv).toLowerCase() === "true"
          ? 1
          : 0;
    }

    // 6) Létezik-e?
    const existing = await database.selectById(id);
    if (!existing) {
      return res.status(404).json({ message: "Nincs ilyen ember." });
    }

    // 7) DB update
    const affected = await database.updatePersonPatch(id, updates);

    // 304 Not Modified (ha semmi nem változott)
    if (affected === 0) {
      return res.status(304).end();
    }

    // 8) Visszaadjuk a friss adatot
    const updated = await database.selectById(id);
    return res.status(200).json({ message: "Sikeres módosítás.", result: updated });
  } catch (err) {
    console.error("PATCH /api/ujemberek/:id hiba:", err);

    // 409 Conflict: duplikált unique (pl. email)
    if (err && (err.code === "ER_DUP_ENTRY" || err.errno === 1062)) {
      return res.status(409).json({ message: "Duplikált adat (pl. email már létezik)." });
    }

    // 500 Internal Server Error
    return res.status(500).json({ message: "Szerverhiba történt." });
  }
});

router.delete("/ujemberek/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);

    // 400 Bad Request
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ message: "Hibás ID. Pozitív egész szám szükséges." });
    }

    // 404 Not Found (ha nincs ilyen)
    const existing = await database.selectById(id);
    if (!existing) {
      return res.status(404).json({ message: "Nincs ilyen ember, nem törölhető." });
    }

    const affected = await database.deleteById(id);

    if (affected === 0) {
      // elméletileg nem várható, mert volt existing check
      return res.status(404).json({ message: "Nincs ilyen ember, nem törölhető." });
    }

    // 204 No Content (törlés sikeres)
    return res.status(204).end();
  } catch (err) {
    console.error("DELETE /api/ujemberek/:id hiba:", err);
    return res.status(500).json({ message: "Szerverhiba történt." });
  }
});

module.exports = router;
