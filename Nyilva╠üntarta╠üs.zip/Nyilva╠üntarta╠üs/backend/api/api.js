const express = require('express');
const router = express.Router();
const database = require('../sql/database.js');
const fs = require('fs/promises');

//!Multer
const multer = require('multer'); //?npm install multer
const path = require('path');

const storage = multer.diskStorage({
  destination: (request, file, callback) => {
    callback(null, path.join(__dirname, '../uploads'));
  },
  filename: (request, file, callback) => {
    callback(null, Date.now() + '-' + file.originalname); //?egyedi név: dátum - file eredeti neve
  }
});

const upload = multer({ storage });

// --- segédfüggvények ---
function isValidDateYYYYMMDD(s) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(s ?? '').trim());
}

function calcAgeFromBirthdate(yyyyMMdd) {
  const s = String(yyyyMMdd ?? "").trim();
  const [y, m, d] = s.split("-").map(Number);
  if (!y || !m || !d) return null;

  const today = new Date();
  let age = today.getFullYear() - y;

  const mm = today.getMonth() + 1;
  const dd = today.getDate();
  if (mm < m || (mm === m && dd < d)) age--;

  return age;
}

function toInt(v) {
  const n = Number(v);
  return Number.isFinite(n) ? Math.trunc(n) : NaN;
}

function toUInt(v) {
  const n = toInt(v);
  return Number.isInteger(n) && n >= 0 ? n : NaN;
}

function normalizeAktiv(v) {
  return v === true ||
    v === 1 ||
    v === "1" ||
    String(v).toLowerCase() === "true"
    ? 1
    : 0;
}

//!Endpoints:
//?GET /api/test
router.get('/test', (request, response) => {
  response.status(200).json({
    message: 'Ez a végpont működik.'
  });
});

//?GET /api/testsql
router.get('/testsql', async (request, response) => {
  try {
    const selectall = await database.selectall();
    response.status(200).json({
      message: 'Ez a végpont működik.',
      results: selectall
    });
  } catch (error) {
    response.status(500).json({
      message: 'Ez a végpont nem működik.'
    });
  }
});


//?POST /api/ujemberek  (ÚJ ember felvitele) - a teljes táblához igazítva
router.post("/ujemberek", async (req, res) => {
  try {
    const ct = req.headers["content-type"] || "";
    if (!ct.includes("application/json")) {
      return res.status(415).json({ message: "Content-Type legyen application/json." });
    }

    const b = req.body || {};

    const vezeteknev = String(b.vezeteknev ?? "").trim();
    const keresztnev = String(b.keresztnev ?? "").trim();
    const nem = String(b.nem ?? "").trim(); // 'férfi' | 'nő'
    const szuletesi_datum = String(b.szuletesi_datum ?? "").trim();

    const email = String(b.email ?? "").trim();
    const telefon = String(b.telefon ?? "").trim();
    const varos = String(b.varos ?? "").trim();
    const iranyitoszam = toUInt(b.iranyitoszam);

    const foglalkozas = String(b.foglalkozas ?? "").trim();
    const fizetes = toUInt(b.fizetes);

    const belepes_datuma = String(b.belepes_datuma ?? "").trim();

    const aktiv = normalizeAktiv(b.aktiv);

    const megjegyzes = String(b.megjegyzes ?? "").trim();
    const felhasznalonev = String(b.felhasznalonev ?? "").trim();
    const jelszo = String(b.jelszo ?? "").trim(); // CHAR(8)

    // --- Validációk (a te táblád NOT NULL mezői szerint) ---
    if (!vezeteknev || !keresztnev) {
      return res.status(422).json({ message: "Vezetéknév és keresztnév kötelező." });
    }

    if (nem !== "férfi" && nem !== "nő") {
      return res.status(422).json({ message: "Nem mező csak 'férfi' vagy 'nő' lehet." });
    }

    if (!isValidDateYYYYMMDD(szuletesi_datum)) {
      return res.status(422).json({ message: "Születési dátum formátuma YYYY-MM-DD legyen." });
    }

    const eletkor = calcAgeFromBirthdate(szuletesi_datum);
    if (eletkor === null || eletkor < 0 || eletkor > 130) {
      return res.status(422).json({ message: "A születési dátumból számolt életkor érvénytelen." });
    }

    if (!email.includes("@") || email.length < 6) {
      return res.status(422).json({ message: "Hibás email formátum." });
    }

    if (!telefon) {
      return res.status(422).json({ message: "Telefon kötelező." });
    }

    if (!varos) {
      return res.status(422).json({ message: "Város kötelező." });
    }

    if (!Number.isInteger(iranyitoszam) || iranyitoszam <= 0) {
      return res.status(422).json({ message: "Irányítószám hibás." });
    }

    if (!foglalkozas) {
      return res.status(422).json({ message: "Foglalkozás kötelező." });
    }

    if (!Number.isInteger(fizetes) || fizetes < 0) {
      return res.status(422).json({ message: "Fizetés hibás." });
    }

    if (!isValidDateYYYYMMDD(belepes_datuma)) {
      return res.status(422).json({ message: "Belépés dátuma formátuma YYYY-MM-DD legyen." });
    }

    if (!megjegyzes) {
      return res.status(422).json({ message: "Megjegyzés kötelező (adhatsz '-' jelet is)." });
    }

    if (!felhasznalonev) {
      return res.status(422).json({ message: "Felhasználónév kötelező." });
    }

    if (jelszo.length !== 8) {
      return res.status(422).json({ message: "Jelszó pontosan 8 karakter legyen." });
    }

    // --- Duplikáció ellenőrzések (UNIQUE: email + felhasznalonev) ---
    const existingEmail = await database.selectByEmail(email);
    if (existingEmail) {
      return res.status(409).json({ message: "Ilyen email már létezik az adatbázisban." });
    }

    if (database.selectByFelhasznalonev) {
      const existingUser = await database.selectByFelhasznalonev(felhasznalonev);
      if (existingUser) {
        return res.status(409).json({ message: "Ilyen felhasználónév már létezik az adatbázisban." });
      }
    }

    // --- INSERT ---
    const created = await database.insertPerson({
      vezeteknev,
      keresztnev,
      nem,
      szuletesi_datum,
      eletkor, // számolt
      email,
      telefon,
      varos,
      iranyitoszam,
      foglalkozas,
      fizetes,
      belepes_datuma,
      aktiv,
      megjegyzes,
      felhasznalonev,
      jelszo
    });

    const inserted = await database.selectById(created.insertId);

    return res.status(201).json({ message: "Sikeres hozzáadás.", result: inserted });
  } catch (err) {
    console.error("POST /ujemberek hiba:", err);

    if (err && (err.code === "ER_DUP_ENTRY" || err.errno === 1062)) {
      return res.status(409).json({ message: "Duplikált adat (email vagy felhasználónév már létezik)." });
    }

    return res.status(500).json({ message: "Szerverhiba történt." });
  }
});


//? POST /api/ujemberek  (ÚJ felhasználó felvitele – egyszerű tábla)
router.post("/ujemberek", async (req, res) => {
  try {
    const ct = req.headers["content-type"] || "";
    if (!ct.includes("application/json")) {
      return res
        .status(415)
        .json({ message: "Content-Type legyen application/json." });
    }

    const b = req.body || {};

    const ujnev = String(b.ujnev ?? "").trim();
    const ujfelhasznalonev = String(b.ujfelhasznalonev ?? "").trim();
    const ujemail = String(b.ujemail ?? "").trim();
    const ujjelszo = String(b.ujjelszo ?? "").trim();

    // --- Validációk (NOT NULL mezők) ---
    if (!ujnev) {
      return res.status(422).json({ message: "Név megadása kötelező." });
    }

    if (!ujfelhasznalonev) {
      return res
        .status(422)
        .json({ message: "Felhasználónév megadása kötelező." });
    }

    if (!ujemail || !ujemail.includes("@") || ujemail.length < 6) {
      return res.status(422).json({ message: "Hibás email formátum." });
    }

    if (!ujjelszo || ujjelszo.length < 6) {
      return res.status(422).json({
        message: "Jelszó kötelező (legalább 6 karakter).",
      });
    }

    // --- Duplikáció ellenőrzések (ha UNIQUE az email / felhasználónév) ---
    if (database.selectUjByEmail) {
      const existingEmail = await database.selectUjByEmail(ujemail);
      if (existingEmail) {
        return res
          .status(409)
          .json({ message: "Ez az email már létezik." });
      }
    }

    if (database.selectUjByFelhasznalonev) {
      const existingUser =
        await database.selectUjByFelhasznalonev(ujfelhasznalonev);
      if (existingUser) {
        return res
          .status(409)
          .json({ message: "Ez a felhasználónév már létezik." });
      }
    }

    // --- INSERT ---
    const created = await database.insertUjFelhasznalo({
      ujnev,
      ujfelhasznalonev,
      ujemail,
      ujjelszo,
    });

    const inserted = await database.selectUjById(created.insertId);

    return res.status(201).json({
      message: "Sikeres hozzáadás.",
      result: inserted,
    });
  } catch (err) {
    console.error("POST /ujemberek hiba:", err);

    if (err && (err.code === "ER_DUP_ENTRY" || err.errno === 1062)) {
      return res.status(409).json({
        message: "Duplikált adat (email vagy felhasználónév már létezik).",
      });
    }

    return res.status(500).json({ message: "Szerverhiba történt." });
  }
});









//?PATCH /api/ujemberek/:id  (Mentés) - bővítve a táblamezőkkel
router.patch("/ujemberek/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ message: "Hibás ID. Pozitív egész szám szükséges." });
    }

    const ct = req.headers["content-type"] || "";
    if (!ct.includes("application/json")) {
      return res.status(415).json({ message: "Content-Type legyen application/json." });
    }

    const body = req.body;
    if (!body || Object.keys(body).length === 0) {
      return res.status(400).json({ message: "Üres kérés. Nincs módosítandó mező." });
    }

    // Engedélyezett mezők (ember_id NEM)
    const allowed = new Set([
      "vezeteknev",
      "keresztnev",
      "nem",
      "szuletesi_datum",
      "email",
      "telefon",
      "varos",
      "iranyitoszam",
      "foglalkozas",
      "fizetes",
      "belepes_datuma",
      "aktiv",
      "megjegyzes",
      "felhasznalonev",
      "jelszo",
    ]);

    const updates = {};

    for (const [key, value] of Object.entries(body)) {
      if (!allowed.has(key)) {
        return res.status(422).json({ message: `Nem módosítható mező: ${key}` });
      }
      updates[key] = value;
    }

    // alap validációk (csak ha küldik)
    if (updates.email !== undefined) {
      const em = String(updates.email);
      if (!em.includes("@") || em.length < 6) {
        return res.status(422).json({ message: "Hibás email formátum." });
      }
      updates.email = em.trim();
    }

    if (updates.felhasznalonev !== undefined) {
      updates.felhasznalonev = String(updates.felhasznalonev ?? "").trim();
      if (!updates.felhasznalonev) {
        return res.status(422).json({ message: "Felhasználónév nem lehet üres." });
      }
    }

    if (updates.jelszo !== undefined) {
      updates.jelszo = String(updates.jelszo ?? "").trim();
      if (updates.jelszo.length !== 8) {
        return res.status(422).json({ message: "Jelszó pontosan 8 karakter legyen." });
      }
    }

    if (updates.nem !== undefined) {
      const n = String(updates.nem ?? "").trim();
      if (n !== "férfi" && n !== "nő") {
        return res.status(422).json({ message: "Nem mező csak 'férfi' vagy 'nő' lehet." });
      }
      updates.nem = n;
    }

    if (updates.szuletesi_datum !== undefined) {
      const sd = String(updates.szuletesi_datum ?? "").trim();
      if (!isValidDateYYYYMMDD(sd)) {
        return res.status(422).json({ message: "A születési dátum formátuma YYYY-MM-DD legyen." });
      }
      updates.szuletesi_datum = sd;

      // ha születési dátum változik, számoljuk újra az életkort is
      const age = calcAgeFromBirthdate(sd);
      if (age === null || age < 0 || age > 130) {
        return res.status(422).json({ message: "A születési dátumból számolt életkor érvénytelen." });
      }
      updates.eletkor = age; // DB mező
    }

    if (updates.belepes_datuma !== undefined) {
      const bd = String(updates.belepes_datuma ?? "").trim();
      if (!isValidDateYYYYMMDD(bd)) {
        return res.status(422).json({ message: "A belépés dátuma formátuma YYYY-MM-DD legyen." });
      }
      updates.belepes_datuma = bd;
    }

    if (updates.iranyitoszam !== undefined) {
      const irsz = toUInt(updates.iranyitoszam);
      if (!Number.isInteger(irsz) || irsz <= 0) {
        return res.status(422).json({ message: "Irányítószám hibás." });
      }
      updates.iranyitoszam = irsz;
    }

    if (updates.fizetes !== undefined) {
      const f = toUInt(updates.fizetes);
      if (!Number.isInteger(f) || f < 0) {
        return res.status(422).json({ message: "Fizetés hibás." });
      }
      updates.fizetes = f;
    }

    if (updates.aktiv !== undefined) {
      updates.aktiv = normalizeAktiv(updates.aktiv);
    }

    // Létezik-e?
    const existing = await database.selectById(id);
    if (!existing) {
      return res.status(404).json({ message: "Nincs ilyen ember." });
    }

    // DB update
    const affected = await database.updatePersonPatch(id, updates);

    if (affected === 0) {
      return res.status(304).end();
    }

    const updated = await database.selectById(id);
    return res.status(200).json({ message: "Sikeres módosítás.", result: updated });
  } catch (err) {
    console.error("PATCH /api/ujemberek/:id hiba:", err);

    if (err && (err.code === "ER_DUP_ENTRY" || err.errno === 1062)) {
      return res.status(409).json({ message: "Duplikált adat (email vagy felhasználónév már létezik)." });
    }

    return res.status(500).json({ message: "Szerverhiba történt." });
  }
});


//?DELETE /api/ujemberek/:id
router.delete("/ujemberek/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ message: "Hibás ID. Pozitív egész szám szükséges." });
    }

    const existing = await database.selectById(id);
    if (!existing) {
      return res.status(404).json({ message: "Nincs ilyen ember, nem törölhető." });
    }

    const affected = await database.deleteById(id);

    if (affected === 0) {
      return res.status(404).json({ message: "Nincs ilyen ember, nem törölhető." });
    }

    return res.status(204).end();
  } catch (err) {
    console.error("DELETE /api/ujemberek/:id hiba:", err);
    return res.status(500).json({ message: "Szerverhiba történt." });
  }
});

// POST /api/ujemberek
router.post("/api/ujemberek", async (req, res) => {
  try {
    const b = req.body || {};
    const { ujnev, ujfelhasznalonev, ujemail, ujjelszo } = b;

    // --- egyszerű validáció ---
    if (!ujnev || !ujfelhasznalonev || !ujemail || !ujjelszo) {
      return res.status(422).json({ message: "Minden mező kötelező." });
    }

    if (ujjelszo.length !== 8) {
      return res.status(422).json({ message: "Jelszó pontosan 8 karakter legyen." });
    }

    // --- INSERT ---
    const created = await database.insertUjFelhasznalo({ ujnev, ujfelhasznalonev, ujemail, ujjelszo });

    return res.status(201).json({
      message: "Sikeres hozzáadás",
      result: { ujid: created.insertId, ujnev, ujfelhasznalonev, ujemail },
    });
  } catch (err) {
    console.error("POST /api/ujemberek hiba:", err);
    return res.status(500).json({ message: "Szerverhiba történt." });
  }
});

// GET /api/ujemberek
router.get("/api/ujemberek", async (req, res) => {
  try {
    const [rows] = await pool.execute("SELECT ujid, ujnev, ujfelhasznalonev, ujemail FROM ujtabela ORDER BY ujid DESC");
    res.json(rows);
  } catch (err) {
    console.error("GET /api/ujemberek hiba:", err);
    res.status(500).json({ message: "Szerverhiba történt." });
  }
});

// DELETE /api/ujemberek/:id
router.delete("/api/ujemberek/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (!Number.isInteger(id)) return res.status(422).json({ message: "Hibás ID." });

    const [result] = await pool.execute("DELETE FROM ujtabela WHERE ujid = ?", [id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: "Nem található ID." });

    res.status(204).send();
  } catch (err) {
    console.error("DELETE /api/ujemberek/:id hiba:", err);
    res.status(500).json({ message: "Szerverhiba történt." });
  }
});




module.exports = router;

