const API_BASE = "/api/ujemberek";

let ujemberek = [];

const elemek = {
  form: document.getElementById("ujemberForm"),
  tbody: document.getElementById("tablaBody"),
  counter: document.getElementById("counterText"),
  status: document.getElementById("statusAlert"),
};


function setStatus(type, msg) {
  elemek.status.className = `alert alert-${type}`;
  elemek.status.innerHTML = msg;
}


async function createUjEmber(data) {
  try {
    const res = await fetch(API_BASE, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    const text = await res.text();

    if (!res.ok) {
      let msg = text;
      try {
        msg = JSON.parse(text).message ?? text;
      } catch {}
      alert(`Hiba hozzáadáskor (${res.status}): ${msg}`);
      return null;
    }

    const json = JSON.parse(text);
    return json.result ?? null;
  } catch (err) {
    console.error("[CREATE] hálózati hiba:", err);
    alert("Hálózati hiba hozzáadáskor: " + err.message);
    return null;
  }
}


async function loadUjEmberek() {
  try {
    setStatus("info", "Betöltés...");

    const res = await fetch(API_BASE);
    if (!res.ok) throw new Error(res.status);

    ujemberek = await res.json();
    renderTable();

    setStatus("success", "Adatok betöltve.");
  } catch (err) {
    console.error("[LOAD] hiba:", err);
    setStatus("danger", "Hiba az adatok betöltésekor.");
  }
}


function renderTable() {
  elemek.tbody.innerHTML = "";

  for (const u of ujemberek) {
    const tr = document.createElement("tr");
    tr.dataset.id = u.ujid;

    tr.innerHTML = `
      <td>${u.ujid}</td>
      <td>${escapeHtml(u.ujnev)}</td>
      <td>${escapeHtml(u.ujfelhasznalonev)}</td>
      <td>${escapeHtml(u.ujemail)}</td>
      <td class="text-center">
        <button class="btn btn-sm btn-danger btn-del">Törlés</button>
      </td>
    `;

    tr.querySelector(".btn-del").addEventListener("click", () =>
      deleteRow(tr)
    );

    elemek.tbody.appendChild(tr);
  }

  elemek.counter.textContent = `Találatok: ${ujemberek.length}`;
}


async function deleteRow(tr) {
  const id = tr.dataset.id;
  if (!id) return;

  if (!confirm(`Biztosan törlöd ezt a felhasználót? (ID: ${id})`)) return;

  const btn = tr.querySelector(".btn-del");
  btn.disabled = true;
  btn.textContent = "Törlés...";

  const ok = await deleteById(id);

  if (ok) {
    ujemberek = ujemberek.filter((x) => String(x.ujid) !== String(id));
    tr.remove();
    elemek.counter.textContent = `Találatok: ${ujemberek.length}`;
    setStatus("success", `Sikeres törlés (ID: ${id})`);
  } else {
    btn.disabled = false;
    btn.textContent = "Törlés";
    setStatus("danger", `Törlési hiba (ID: ${id})`);
  }
}

async function deleteById(id) {
  try {
    const res = await fetch(`${API_BASE}/${id}`, { method: "DELETE" });
    return res.status === 204;
  } catch (err) {
    console.error("[DEL] hálózati hiba:", err);
    alert("Hálózati hiba törléskor: " + err.message);
    return false;
  }
}


elemek.form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const data = {
    ujnev: elemek.form.ujnev.value.trim(),
    ujfelhasznalonev: elemek.form.ujfelhasznalonev.value.trim(),
    ujemail: elemek.form.ujemail.value.trim(),
    ujjelszo: elemek.form.ujjelszo.value.trim(),
  };

  const created = await createUjEmber(data);
  if (!created) return;

  ujemberek.push(created);
  renderTable();
  elemek.form.reset();

  setStatus("success", "Sikeres hozzáadás.");
});


function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}


loadUjEmberek();
