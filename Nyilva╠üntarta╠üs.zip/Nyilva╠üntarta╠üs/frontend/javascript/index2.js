// ../javascript/index.js
// GET lista:  http://127.0.0.1:3000/api/testsql
// PATCH mentés: http://127.0.0.1:3000/api/ujemberek/:id
// DELETE törlés: http://127.0.0.1:3000/api/ujemberek/:id

const API_GET_URL = "http://127.0.0.1:3000/api/testsql";
const API_BASE = "http://127.0.0.1:3000/api/ujemberek";

let ujemberek = [];

const elemek = {
  status: document.getElementById("statusAlert"),
  btnLoad: document.getElementById("btnLoad"),
  btnClear: document.getElementById("btnClear"),
  tbody: document.getElementById("tablaBody"),
  counter: document.getElementById("counterText"),
  fV: document.getElementById("fVezeteknev"),
  fK: document.getElementById("fKeresztnev"),
  fVa: document.getElementById("fVaros"),
  fE: document.getElementById("fEmail"),
  fA: document.getElementById("fAktiv"),
};

function setStatus(type, msg) {
  elemek.status.className = `alert alert-${type} mb-0`;
  elemek.status.innerHTML = msg;
}

function escapeHtml(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function normalizeAktiv(v) {
  return v === true || v === 1 || v === "1";
}

// -------------------- GET --------------------
async function loadData() {
  setStatus("info", "Betöltés folyamatban...");
  elemek.btnLoad.disabled = true;

  try {
    const res = await fetch(API_GET_URL);
    if (!res.ok) {
      setStatus("danger", `Hiba: ${res.status} ${res.statusText}`);
      return;
    }

    const data = await res.json();
    if (Array.isArray(data)) ujemberek = data;
    else if (Array.isArray(data.results)) ujemberek = data.results;
    else if (Array.isArray(data.rows)) ujemberek = data.rows;
    else if (Array.isArray(data.data)) ujemberek = data.data;
    else ujemberek = [];

    setStatus("success", `Sikeres betöltés. Rekordok: <strong>${ujemberek.length}</strong>`);
    applyFilters();
  } catch (err) {
    setStatus("danger", `Hálózati hiba: ${err.message}`);
  } finally {
    elemek.btnLoad.disabled = false;
  }
}

// -------------------- RENDER --------------------
function render(lista) {
  elemek.tbody.innerHTML = "";

  lista.forEach((e) => {
    const id = e.ember_id ?? e.id ?? e.ID;
    const tr = document.createElement("tr");
    tr.dataset.id = String(id);
    tr.dataset.dirty = "0";

    tr.innerHTML = `
      <td>${escapeHtml(id)}</td>

      <td><input class="form-control form-control-sm" data-field="vezeteknev" value="${escapeHtml(e.vezeteknev)}"></td>
      <td><input class="form-control form-control-sm" data-field="keresztnev" value="${escapeHtml(e.keresztnev)}"></td>
      <td><input class="form-control form-control-sm" data-field="varos" value="${escapeHtml(e.varos)}"></td>
      <td><input class="form-control form-control-sm" data-field="email" value="${escapeHtml(e.email)}"></td>

      <td class="text-center">
        <input type="checkbox" class="form-check-input" data-field="aktiv" ${normalizeAktiv(e.aktiv) ? "checked" : ""}>
      </td>

      <td class="text-center d-flex gap-2 justify-content-center">
        <button class="btn btn-sm btn-success btn-save" type="button">Mentés</button>
        <button class="btn btn-sm btn-danger btn-del" type="button">Törlés</button>
      </td>
    `;

    // dirty jelölés (ha bármit módosítanak a sorban)
    tr.querySelectorAll("input").forEach((inp) => {
      inp.addEventListener("input", () => markDirty(tr, true));
      inp.addEventListener("change", () => markDirty(tr, true));
    });

    // mentés
    tr.querySelector(".btn-save").addEventListener("click", () => saveRow(tr));

    // törlés
    tr.querySelector(".btn-del").addEventListener("click", () => deleteRow(tr));

    elemek.tbody.appendChild(tr);
  });

  elemek.counter.textContent = `Találatok: ${lista.length}`;
}

function markDirty(tr, dirty) {
  const btn = tr.querySelector(".btn-save");
  if (!btn) return;

  if (dirty) {
    tr.dataset.dirty = "1";
    btn.disabled = false;
    btn.classList.remove("btn-outline-success", "btn-danger");
    btn.classList.add("btn-success");
    btn.textContent = "Mentés";
  } else {
    tr.dataset.dirty = "0";
    btn.classList.remove("btn-success", "btn-danger");
    btn.classList.add("btn-outline-success");
    btn.textContent = "Mentve";
    btn.disabled = false;
  }
}

// -------------------- PATCH (MENTÉS) --------------------
async function saveRow(tr) {
  const id = tr.dataset.id;
  if (!id) return;

  if (tr.dataset.dirty !== "1") {
    setStatus("secondary", `Nincs változás a sorban: <strong>#${escapeHtml(id)}</strong>`);
    return;
  }

  const btn = tr.querySelector(".btn-save");
  btn.disabled = true;
  btn.textContent = "Mentés...";

  const data = collectRowData(tr);

  const ok = await patchRow(id, data);

  if (ok) {
    markDirty(tr, false);
    setStatus("success", `Sikeres mentés: <strong>#${escapeHtml(id)}</strong>`);
  } else {
    btn.disabled = false;
    btn.textContent = "Hiba";
    btn.classList.remove("btn-success", "btn-outline-success");
    btn.classList.add("btn-danger");
    setStatus("danger", `Mentési hiba ennél az ID-nál: <strong>#${escapeHtml(id)}</strong>`);
  }
}

function collectRowData(tr) {
  const inputs = tr.querySelectorAll("input");
  const data = {};

  inputs.forEach((inp) => {
    const field = inp.dataset.field;
    if (!field) return;

    if (inp.type === "checkbox") data[field] = inp.checked;
    else data[field] = inp.value;
  });

  // Csak a Mentés gomb mezőit küldjük
  return {
    vezeteknev: data.vezeteknev ?? "",
    keresztnev: data.keresztnev ?? "",
    varos: data.varos ?? "",
    email: data.email ?? "",
    aktiv: Boolean(data.aktiv),
  };
}

async function patchRow(id, data) {
  try {
    const url = `${API_BASE}/${id}`;
    console.log(`[SAVE] PATCH ${url}`, data);

    const res = await fetch(url, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    const text = await res.text();
    console.log(`[SAVE] <- ${res.status}`, text);

    if (!res.ok) {
      alert(`Mentési hiba (${res.status}): ${text}`);
      return false;
    }

    return true;
  } catch (err) {
    console.error("[SAVE] hálózati hiba:", err);
    alert("Hálózati hiba mentéskor: " + err.message);
    return false;
  }
}

// -------------------- DELETE (TÖRLÉS) --------------------
async function deleteRow(tr) {
  const id = tr.dataset.id;
  if (!id) return;

  if (!confirm(`Biztosan törlöd ezt az embert? (ID: ${id})`)) return;

  const btnDel = tr.querySelector(".btn-del");
  btnDel.disabled = true;
  btnDel.textContent = "Törlés...";

  const ok = await deleteById(id);

  if (ok) {
    // töröljük a lokális tömbből is, hogy ne jöjjön vissza szűrésnél
    ujemberek = ujemberek.filter((x) => String(x.ember_id ?? x.id ?? x.ID) !== String(id));

    // sor eltávolítása a DOM-ból
    tr.remove();

    // számláló frissítés (aktuális táblában lévő sorok alapján)
    elemek.counter.textContent = `Találatok: ${elemek.tbody.querySelectorAll("tr").length}`;

    setStatus("success", `Sikeres törlés: <strong>#${escapeHtml(id)}</strong>`);
  } else {
    btnDel.disabled = false;
    btnDel.textContent = "Törlés";
    setStatus("danger", `Törlési hiba ennél az ID-nál: <strong>#${escapeHtml(id)}</strong>`);
  }
}

async function deleteById(id) {
  try {
    const url = `${API_BASE}/${id}`;
    console.log(`[DEL] DELETE ${url}`);

    const res = await fetch(url, { method: "DELETE" });

    // 204 a siker
    if (res.status === 204) return true;

    const text = await res.text().catch(() => "");
    console.log(`[DEL] <- ${res.status}`, text);

    alert(`Törlési hiba (${res.status}): ${text}`);
    return false;
  } catch (err) {
    console.error("[DEL] hálózati hiba:", err);
    alert("Hálózati hiba törléskor: " + err.message);
    return false;
  }
}

// -------------------- SZŰRÉS --------------------
function applyFilters() {
  const v = (elemek.fV.value || "").trim().toLowerCase();
  const k = (elemek.fK.value || "").trim().toLowerCase();
  const va = (elemek.fVa.value || "").trim().toLowerCase();
  const em = (elemek.fE.value || "").trim().toLowerCase();
  const akt = elemek.fA.value; // "", "1", "0"

  const filtered = ujemberek.filter((e) => {
    const okV = String(e.vezeteknev ?? "").toLowerCase().includes(v);
    const okK = String(e.keresztnev ?? "").toLowerCase().includes(k);
    const okVa = String(e.varos ?? "").toLowerCase().includes(va);
    const okEm = String(e.email ?? "").toLowerCase().includes(em);

    const isAktiv = normalizeAktiv(e.aktiv);
    const okAkt = akt === "" || Number(isAktiv) === Number(akt);

    return okV && okK && okVa && okEm && okAkt;
  });

  render(filtered);
}

function clearFilters() {
  elemek.fV.value = "";
  elemek.fK.value = "";
  elemek.fVa.value = "";
  elemek.fE.value = "";
  elemek.fA.value = "";
  applyFilters();
}

// -------------------- ESEMÉNYEK --------------------
elemek.btnLoad.addEventListener("click", loadData);
elemek.btnClear.addEventListener("click", clearFilters);

[elemek.fV, elemek.fK, elemek.fVa, elemek.fE].forEach((el) =>
  el.addEventListener("input", applyFilters)
);
elemek.fA.addEventListener("change", applyFilters);

// kezdő státusz
setStatus("info", "Készen áll. Kattints a <strong>Betöltés</strong> gombra.");

