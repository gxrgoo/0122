// ../javascript/index.js
// GET lista:     http://127.0.0.1:3000/api/testsql
// POST felvitel: http://127.0.0.1:3000/api/ujemberek
// PATCH mentés:  http://127.0.0.1:3000/api/ujemberek/:id
// DELETE törlés: http://127.0.0.1:3000/api/ujemberek/:id

const API_GET_URL = "http://127.0.0.1:3000/api/testsql";
const API_BASE = "http://127.0.0.1:3000/api/ujemberek";

let ujemberek = [];

const elemek = {
  status: document.getElementById("statusAlert"),
  btnLoad: document.getElementById("btnLoad"),
  btnClear: document.getElementById("btnClear"),
  tbody: document.getElementById("tablaBody"),
  counter: document.getElementById("counterText"),
  fV: document.getElementById("fVezeteknev"),
  fK: document.getElementById("fKeresztnev"),
  fVa: document.getElementById("fVaros"),
  fE: document.getElementById("fEmail"),
  fA: document.getElementById("fAktiv"),
};

function setStatus(type, msg) {
  elemek.status.className = `alert alert-${type} mb-0`;
  elemek.status.innerHTML = msg;
}

function escapeHtml(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function normalizeAktiv(v) {
  return v === true || v === 1 || v === "1";
}

function normalizeDateForInput(v) {
  const s = String(v ?? "").trim();
  if (!s) return "";
  return s.length >= 10 ? s.slice(0, 10) : s;
}

function isValidDateYYYYMMDD(s) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(s ?? "").trim());
}

function toUInt(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return NaN;
  const i = Math.trunc(n);
  return i >= 0 ? i : NaN;
}

// -------------------- GET --------------------
async function loadData() {
  setStatus("info", "Betöltés folyamatban...");
  elemek.btnLoad.disabled = true;

  try {
    const res = await fetch(API_GET_URL);
    if (!res.ok) {
      setStatus("danger", `Hiba: ${res.status} ${res.statusText}`);
      return;
    }

    const data = await res.json();
    if (Array.isArray(data)) ujemberek = data;
    else if (Array.isArray(data.results)) ujemberek = data.results;
    else if (Array.isArray(data.rows)) ujemberek = data.rows;
    else if (Array.isArray(data.data)) ujemberek = data.data;
    else ujemberek = [];

    setStatus("success", `Sikeres betöltés. Rekordok: <strong>${ujemberek.length}</strong>`);
    applyFilters();
  } catch (err) {
    setStatus("danger", `Hálózati hiba: ${err.message}`);
  } finally {
    elemek.btnLoad.disabled = false;
  }
}

// -------------------- RENDER --------------------
// Megjelenítjük/szerkeszthetővé tesszük a legfontosabb mezőket,
// amik a táblában NOT NULL-ok és a PATCH is kezeli őket.
function render(lista) {
  elemek.tbody.innerHTML = "";

  lista.forEach((e) => {
    const id = e.ember_id ?? e.id ?? e.ID;
    const tr = document.createElement("tr");
    tr.dataset.id = String(id);
    tr.dataset.dirty = "0";

    tr.innerHTML = `
      <td>${escapeHtml(id)}</td>

      <td><input class="form-control form-control-sm" data-field="vezeteknev" value="${escapeHtml(e.vezeteknev)}"></td>
      <td><input class="form-control form-control-sm" data-field="keresztnev" value="${escapeHtml(e.keresztnev)}"></td>

      <td>
        <select class="form-select form-select-sm" data-field="nem">
          <option value="férfi" ${String(e.nem) === "férfi" ? "selected" : ""}>férfi</option>
          <option value="nő" ${String(e.nem) === "nő" ? "selected" : ""}>nő</option>
        </select>
      </td>

      <td>
        <input type="date" class="form-control form-control-sm" data-field="szuletesi_datum"
          value="${escapeHtml(normalizeDateForInput(e.szuletesi_datum))}">
      </td>

      <td><input class="form-control form-control-sm" data-field="email" value="${escapeHtml(e.email)}"></td>
      <td><input class="form-control form-control-sm" data-field="telefon" value="${escapeHtml(e.telefon)}"></td>

      <td><input class="form-control form-control-sm" data-field="varos" value="${escapeHtml(e.varos)}"></td>
      <td><input class="form-control form-control-sm" data-field="iranyitoszam" value="${escapeHtml(e.iranyitoszam)}"></td>

      <td><input class="form-control form-control-sm" data-field="foglalkozas" value="${escapeHtml(e.foglalkozas)}"></td>
      <td><input class="form-control form-control-sm" data-field="fizetes" value="${escapeHtml(e.fizetes)}"></td>

      <td>
        <input type="date" class="form-control form-control-sm" data-field="belepes_datuma"
          value="${escapeHtml(normalizeDateForInput(e.belepes_datuma))}">
      </td>

      <td><input class="form-control form-control-sm" data-field="felhasznalonev" value="${escapeHtml(e.felhasznalonev)}"></td>
      <td><input class="form-control form-control-sm" data-field="jelszo" value="${escapeHtml(e.jelszo)}" maxlength="8"></td>

      <td><input class="form-control form-control-sm" data-field="megjegyzes" value="${escapeHtml(e.megjegyzes)}"></td>

      <td class="text-center">
        <input type="checkbox" class="form-check-input" data-field="aktiv" ${normalizeAktiv(e.aktiv) ? "checked" : ""}>
      </td>

      <td class="text-center d-flex gap-2 justify-content-center">
        <button class="btn btn-sm btn-success btn-save" type="button">Mentés</button>
        <button class="btn btn-sm btn-danger btn-del" type="button">Törlés</button>
      </td>
    `;

    // dirty jelölés
    tr.querySelectorAll("input, select").forEach((inp) => {
      inp.addEventListener("input", () => markDirty(tr, true));
      inp.addEventListener("change", () => markDirty(tr, true));
    });

    tr.querySelector(".btn-save").addEventListener("click", () => saveRow(tr));
    tr.querySelector(".btn-del").addEventListener("click", () => deleteRow(tr));

    elemek.tbody.appendChild(tr);
  });

  elemek.counter.textContent = `Találatok: ${lista.length}`;
}

function markDirty(tr, dirty) {
  const btn = tr.querySelector(".btn-save");
  if (!btn) return;

  if (dirty) {
    tr.dataset.dirty = "1";
    btn.disabled = false;
    btn.classList.remove("btn-outline-success", "btn-danger");
    btn.classList.add("btn-success");
    btn.textContent = "Mentés";
  } else {
    tr.dataset.dirty = "0";
    btn.classList.remove("btn-success", "btn-danger");
    btn.classList.add("btn-outline-success");
    btn.textContent = "Mentve";
    btn.disabled = false;
  }
}

// -------------------- PATCH (MENTÉS) --------------------
async function saveRow(tr) {
  const id = tr.dataset.id;
  if (!id) return;

  if (tr.dataset.dirty !== "1") {
    setStatus("secondary", `Nincs változás a sorban: <strong>#${escapeHtml(id)}</strong>`);
    return;
  }

  const btn = tr.querySelector(".btn-save");
  btn.disabled = true;
  btn.textContent = "Mentés...";

  const data = collectRowData(tr);

  // minimál kliens oldali ellenőrzések (a szerver is ellenőrzi)
  if (!data.vezeteknev || !data.keresztnev) {
    alert("Vezetéknév és keresztnév kötelező.");
    btn.disabled = false;
    btn.textContent = "Hiba";
    return;
  }
  if (data.nem !== "férfi" && data.nem !== "nő") {
    alert("Nem mező csak 'férfi' vagy 'nő' lehet.");
    btn.disabled = false;
    btn.textContent = "Hiba";
    return;
  }
  if (!isValidDateYYYYMMDD(data.szuletesi_datum)) {
    alert("Születési dátum hibás (YYYY-MM-DD).");
    btn.disabled = false;
    btn.textContent = "Hiba";
    return;
  }
  if (!data.email.includes("@") || data.email.length < 6) {
    alert("Hibás email formátum.");
    btn.disabled = false;
    btn.textContent = "Hiba";
    return;
  }
  if (!data.telefon) {
    alert("Telefon kötelező.");
    btn.disabled = false;
    btn.textContent = "Hiba";
    return;
  }
  if (!data.varos) {
    alert("Város kötelező.");
    btn.disabled = false;
    btn.textContent = "Hiba";
    return;
  }
  if (!Number.isInteger(toUInt(data.iranyitoszam)) || toUInt(data.iranyitoszam) <= 0) {
    alert("Irányítószám hibás.");
    btn.disabled = false;
    btn.textContent = "Hiba";
    return;
  }
  if (!data.foglalkozas) {
    alert("Foglalkozás kötelező.");
    btn.disabled = false;
    btn.textContent = "Hiba";
    return;
  }
  if (!Number.isInteger(toUInt(data.fizetes)) || toUInt(data.fizetes) < 0) {
    alert("Fizetés hibás.");
    btn.disabled = false;
    btn.textContent = "Hiba";
    return;
  }
  if (!isValidDateYYYYMMDD(data.belepes_datuma)) {
    alert("Belépés dátuma hibás (YYYY-MM-DD).");
    btn.disabled = false;
    btn.textContent = "Hiba";
    return;
  }
  if (!data.felhasznalonev) {
    alert("Felhasználónév kötelező.");
    btn.disabled = false;
    btn.textContent = "Hiba";
    return;
  }
  if ((data.jelszo || "").length !== 8) {
    alert("A jelszó pontosan 8 karakter legyen.");
    btn.disabled = false;
    btn.textContent = "Hiba";
    return;
  }
  if (!data.megjegyzes) {
    alert("Megjegyzés kötelező (adhatsz '-' jelet is).");
    btn.disabled = false;
    btn.textContent = "Hiba";
    return;
  }

  const ok = await patchRow(id, data);

  if (ok) {
    markDirty(tr, false);
    setStatus("success", `Sikeres mentés: <strong>#${escapeHtml(id)}</strong>`);
  } else {
    btn.disabled = false;
    btn.textContent = "Hiba";
    setStatus("danger", `Mentési hiba ennél az ID-nál: <strong>#${escapeHtml(id)}</strong>`);
  }
}

function collectRowData(tr) {
  const inputs = tr.querySelectorAll("input, select");
  const data = {};

  inputs.forEach((inp) => {
    const field = inp.dataset.field;
    if (!field) return;

    if (inp.type === "checkbox") data[field] = inp.checked;
    else data[field] = inp.value;
  });

  return {
    vezeteknev: (data.vezeteknev ?? "").trim(),
    keresztnev: (data.keresztnev ?? "").trim(),
    nem: (data.nem ?? "").trim(),
    szuletesi_datum: normalizeDateForInput(data.szuletesi_datum ?? ""),
    email: (data.email ?? "").trim(),
    telefon: (data.telefon ?? "").trim(),
    varos: (data.varos ?? "").trim(),
    iranyitoszam: (data.iranyitoszam ?? "").toString().trim(),
    foglalkozas: (data.foglalkozas ?? "").trim(),
    fizetes: (data.fizetes ?? "").toString().trim(),
    belepes_datuma: normalizeDateForInput(data.belepes_datuma ?? ""),
    aktiv: Boolean(data.aktiv),
    megjegyzes: (data.megjegyzes ?? "").trim(),
    felhasznalonev: (data.felhasznalonev ?? "").trim(),
    jelszo: (data.jelszo ?? "").trim(),
  };
}

async function patchRow(id, data) {
  try {
    const url = `${API_BASE}/${id}`;
    console.log(`[SAVE] PATCH ${url}`, data);

    const res = await fetch(url, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    const text = await res.text();
    console.log(`[SAVE] <- ${res.status}`, text);

    if (!res.ok) {
      alert(`Mentési hiba (${res.status}): ${text}`);
      return false;
    }

    return true;
  } catch (err) {
    console.error("[SAVE] hálózati hiba:", err);
    alert("Hálózati hiba mentéskor: " + err.message);
    return false;
  }
}

// -------------------- POST (ÚJ FELVITEL) --------------------
async function createPerson(data) {
  try {
    const res = await fetch(API_BASE, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    const text = await res.text();

    if (!res.ok) {
      let msg = text;
      try {
        const j = JSON.parse(text);
        msg = j.message || text;
      } catch {}
      alert(`Hiba hozzáadáskor (${res.status}): ${msg}`);
      return null;
    }

    const j = JSON.parse(text);
    return j.result ?? null;
  } catch (err) {
    console.error("[CREATE] hálózati hiba:", err);
    alert("Hálózati hiba hozzáadáskor: " + err.message);
    return null;
  }
}

// -------------------- DELETE (TÖRLÉS) --------------------
async function deleteRow(tr) {
  const id = tr.dataset.id;
  if (!id) return;

  if (!confirm(`Biztosan törlöd ezt az embert? (ID: ${id})`)) return;

  const btnDel = tr.querySelector(".btn-del");
  btnDel.disabled = true;
  btnDel.textContent = "Törlés...";

  const ok = await deleteById(id);

  if (ok) {
    ujemberek = ujemberek.filter((x) => String(x.ember_id ?? x.id ?? x.ID) !== String(id));
    tr.remove();
    elemek.counter.textContent = `Találatok: ${elemek.tbody.querySelectorAll("tr").length}`;
    setStatus("success", `Sikeres törlés: <strong>#${escapeHtml(id)}</strong>`);
  } else {
    btnDel.disabled = false;
    btnDel.textContent = "Törlés";
    setStatus("danger", `Törlési hiba ennél az ID-nál: <strong>#${escapeHtml(id)}</strong>`);
  }
}

async function deleteById(id) {
  try {
    const url = `${API_BASE}/${id}`;
    console.log(`[DEL] DELETE ${url}`);

    const res = await fetch(url, { method: "DELETE" });

    if (res.status === 204) return true;

    const text = await res.text().catch(() => "");
    console.log(`[DEL] <- ${res.status}`, text);

    alert(`Törlési hiba (${res.status}): ${text}`);
    return false;
  } catch (err) {
    console.error("[DEL] hálózati hiba:", err);
    alert("Hálózati hiba törléskor: " + err.message);
    return false;
  }
}

// -------------------- SZŰRÉS --------------------
function applyFilters() {
  const v = (elemek.fV.value || "").trim().toLowerCase();
  const k = (elemek.fK.value || "").trim().toLowerCase();
  const va = (elemek.fVa.value || "").trim().toLowerCase();
  const em = (elemek.fE.value || "").trim().toLowerCase();
  const akt = elemek.fA.value; // "", "1", "0"

  const filtered = ujemberek.filter((e) => {
    const okV = String(e.vezeteknev ?? "").toLowerCase().includes(v);
    const okK = String(e.keresztnev ?? "").toLowerCase().includes(k);
    const okVa = String(e.varos ?? "").toLowerCase().includes(va);
    const okEm = String(e.email ?? "").toLowerCase().includes(em);

    const isAktiv = normalizeAktiv(e.aktiv);
    const okAkt = akt === "" || Number(isAktiv) === Number(akt);

    return okV && okK && okVa && okEm && okAkt;
  });

  render(filtered);
}

function clearFilters() {
  elemek.fV.value = "";
  elemek.fK.value = "";
  elemek.fVa.value = "";
  elemek.fE.value = "";
  elemek.fA.value = "";
  applyFilters();
}

// -------------------- ÚJ FELVITELI ŰRLAP (dinamikusan) --------------------
(function ensureCreateForm() {
  const anchor = elemek.status;
  if (!anchor || !anchor.parentElement) return;
  if (document.getElementById("createPersonForm")) return;

  const wrap = document.createElement("div");
  wrap.className = "card mt-3";
  wrap.innerHTML = `
    <div class="card-body">
      <h5 class="card-title mb-3">Új ember felvitele</h5>
      <form id="createPersonForm" class="row g-2">

        <div class="col-12 col-md-3">
          <input id="addVezeteknev" class="form-control" placeholder="Vezetéknév *" required />
        </div>
        <div class="col-12 col-md-3">
          <input id="addKeresztnev" class="form-control" placeholder="Keresztnév *" required />
        </div>

        <div class="col-12 col-md-2">
          <select id="addNem" class="form-select" required>
            <option value="férfi">férfi</option>
            <option value="nő">nő</option>
          </select>
        </div>

        <div class="col-12 col-md-2">
          <input id="addSzuletesiDatum" type="date" class="form-control" required />
        </div>

        <div class="col-12 col-md-2">
          <select id="addAktiv" class="form-select">
            <option value="1" selected>Aktív</option>
            <option value="0">Inaktív</option>
          </select>
        </div>

        <div class="col-12 col-md-4">
          <input id="addEmail" type="email" class="form-control" placeholder="Email *" required />
        </div>
        <div class="col-12 col-md-4">
          <input id="addTelefon" class="form-control" placeholder="Telefon *" required />
        </div>

        <div class="col-12 col-md-3">
          <input id="addVaros" class="form-control" placeholder="Város *" required />
        </div>
        <div class="col-12 col-md-1">
          <input id="addIranyitoszam" type="number" class="form-control" placeholder="IRsz *" required />
        </div>

        <div class="col-12 col-md-3">
          <input id="addFoglalkozas" class="form-control" placeholder="Foglalkozás *" required />
        </div>
        <div class="col-12 col-md-2">
          <input id="addFizetes" type="number" class="form-control" placeholder="Fizetés *" required />
        </div>

        <div class="col-12 col-md-2">
          <input id="addBelepesDatuma" type="date" class="form-control" required />
        </div>

        <div class="col-12 col-md-4">
          <input id="addFelhasznalonev" class="form-control" placeholder="Felhasználónév *" required />
        </div>
        <div class="col-12 col-md-2">
          <input id="addJelszo" class="form-control" placeholder="Jelszó (8 karakter) *" minlength="8" maxlength="8" required />
        </div>

        <div class="col-12 col-md-6">
          <input id="addMegjegyzes" class="form-control" placeholder="Megjegyzés * (pl. -)" required />
        </div>

        <div class="col-12 col-md-3">
          <button id="btnAdd" type="submit" class="btn btn-primary w-100">Hozzáadás</button>
        </div>

        <div class="col-12">
          <small class="text-muted">* kötelező mezők</small>
        </div>
      </form>
    </div>
  `;

  anchor.insertAdjacentElement("afterend", wrap);

  elemek.formCreate = document.getElementById("createPersonForm");

  elemek.addV = document.getElementById("addVezeteknev");
  elemek.addK = document.getElementById("addKeresztnev");
  elemek.addNem = document.getElementById("addNem");
  elemek.addSD = document.getElementById("addSzuletesiDatum");
  elemek.addA = document.getElementById("addAktiv");
  elemek.addE = document.getElementById("addEmail");
  elemek.addTelefon = document.getElementById("addTelefon");
  elemek.addVa = document.getElementById("addVaros");
  elemek.addIrsz = document.getElementById("addIranyitoszam");
  elemek.addFog = document.getElementById("addFoglalkozas");
  elemek.addFiz = document.getElementById("addFizetes");
  elemek.addBelepes = document.getElementById("addBelepesDatuma");
  elemek.addUname = document.getElementById("addFelhasznalonev");
  elemek.addPw = document.getElementById("addJelszo");
  elemek.addMegj = document.getElementById("addMegjegyzes");
  elemek.btnAdd = document.getElementById("btnAdd");

  // default dátumok: ma (kényelmi)
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const today = `${yyyy}-${mm}-${dd}`;

  if (!elemek.addSD.value) elemek.addSD.value = today;
  if (!elemek.addBelepes.value) elemek.addBelepes.value = today;

  elemek.formCreate.addEventListener("submit", async (e) => {
    e.preventDefault();

    const payload = {
      vezeteknev: (elemek.addV.value || "").trim(),
      keresztnev: (elemek.addK.value || "").trim(),
      nem: elemek.addNem.value,
      szuletesi_datum: normalizeDateForInput(elemek.addSD.value || ""),
      email: (elemek.addE.value || "").trim(),
      telefon: (elemek.addTelefon.value || "").trim(),
      varos: (elemek.addVa.value || "").trim(),
      iranyitoszam: toUInt(elemek.addIrsz.value),
      foglalkozas: (elemek.addFog.value || "").trim(),
      fizetes: toUInt(elemek.addFiz.value),
      belepes_datuma: normalizeDateForInput(elemek.addBelepes.value || ""),
      aktiv: elemek.addA.value === "1" ? 1 : 0,
      megjegyzes: (elemek.addMegj.value || "").trim(),
      felhasznalonev: (elemek.addUname.value || "").trim(),
      jelszo: (elemek.addPw.value || "").trim(),
    };

    // minimál kliens oldali validáció (a szerver amúgy is validál)
    if (!payload.vezeteknev || !payload.keresztnev) return alert("Vezetéknév és keresztnév kötelező.");
    if (payload.nem !== "férfi" && payload.nem !== "nő") return alert("Nem mező csak 'férfi' vagy 'nő' lehet.");
    if (!isValidDateYYYYMMDD(payload.szuletesi_datum)) return alert("Születési dátum kötelező (YYYY-MM-DD).");
    if (!payload.email.includes("@") || payload.email.length < 6) return alert("Hibás email formátum.");
    if (!payload.telefon) return alert("Telefon kötelező.");
    if (!payload.varos) return alert("Város kötelező.");
    if (!Number.isInteger(payload.iranyitoszam) || payload.iranyitoszam <= 0) return alert("Irányítószám hibás.");
    if (!payload.foglalkozas) return alert("Foglalkozás kötelező.");
    if (!Number.isInteger(payload.fizetes) || payload.fizetes < 0) return alert("Fizetés hibás.");
    if (!isValidDateYYYYMMDD(payload.belepes_datuma)) return alert("Belépés dátuma kötelező (YYYY-MM-DD).");
    if (!payload.felhasznalonev) return alert("Felhasználónév kötelező.");
    if ((payload.jelszo || "").length !== 8) return alert("A jelszó pontosan 8 karakter legyen.");
    if (!payload.megjegyzes) return alert("Megjegyzés kötelező (adhatsz '-' jelet is).");

    elemek.btnAdd.disabled = true;
    elemek.btnAdd.textContent = "Mentés...";

    const created = await createPerson(payload);

    elemek.btnAdd.disabled = false;
    elemek.btnAdd.textContent = "Hozzáadás";

    if (!created) return;

    ujemberek.unshift(created);
    applyFilters();

    elemek.formCreate.reset();
    elemek.addA.value = "1";
    if (!elemek.addSD.value) elemek.addSD.value = today;
    if (!elemek.addBelepes.value) elemek.addBelepes.value = today;

    setStatus("success", "Új rekord hozzáadva az adatbázishoz.");
  });
})();

// -------------------- ESEMÉNYEK --------------------
elemek.btnLoad.addEventListener("click", loadData);
elemek.btnClear.addEventListener("click", clearFilters);

[elemek.fV, elemek.fK, elemek.fVa, elemek.fE].forEach((el) =>
  el.addEventListener("input", applyFilters)
);
elemek.fA.addEventListener("change", applyFilters);

// kezdő státusz
setStatus("info", "Készen áll. Kattints a <strong>Betöltés</strong> gombra.");



